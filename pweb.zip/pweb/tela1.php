<!DOCTYPE html>
<html>
	<head>
		<title> Teste</title>
	</head>
	<body>
		<form action="/pagina-processa-dados-do-form" method="post">
		    <div>
		        <label for="cubo">Qual dos cubos abaixo poderia ser a rotação do cubo acima?</label> <br>
		        <button><input type="image" src="cubo1.webp" class="botao" width="200px" ></button>	
		        <label for="resposta1"> </label> <br>
		    </div>
		    <div>
		        <label for="cubo"></label>
		    </div>
		    
		</form>
	</body>
</html>